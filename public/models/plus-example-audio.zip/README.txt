ADEPS+ independent reconstruction comparison: fixed held-out scene 0000.
10 aligned FOA files: reference plus all 9 methods, FLOAT32 ACN/N3D W,Y,Z,X, 16 kHz / 3968 samples.
10 PCM16 stereo previews: fixed virtual-cardioid pair, not HRTF binaural.
All files share one gain; keep the same decoder/playback level when comparing.
Covariance uses that same gain squared; saved frequency/scalar metrics remain before gain.
plus-example-input.npz reproduces this exact microphone observation through infer_plus.py.
The inference input contains no reference coefficients or true source directions; those remain separate evaluation/presentation records.
Derived VCTK 0.92 audio, CC BY 4.0; authors/files/changes/license are in example.json and dataset/.
No original FLAC corpus, neural weights or HARP source code are included.
One saved example does not establish superiority over the original paper or real-room accuracy.
