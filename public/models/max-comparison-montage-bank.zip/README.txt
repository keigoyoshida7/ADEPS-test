ADEPS-test / saved reconstruction method comparison
Open max/ADEPS_Method_Comparison.maxpat, then choose the root max-comparison.json.
FOA WAVs are already gain-scaled FLOAT32 ACN/N3D W,Y,Z,X. Do not apply shared_gain again.
Use the shared 12x4 decoder exactly once. Stereo cardioid and KU100 metric audio are not included.
All methods use the same synthetic inputs and transport; this is not real-time inference.
The example is 0.248 seconds. Montage scenes retain the same short duration, with declared fades and gaps.
Open does not authorize automatic audio; start, master gain and physical routing are manual.
Read max/README_COMPARISON.md and the manifest, including the saved channel 11/12 discrepancy.
VCTK attribution and original license documents are included. No original corpus, model weights or new scores.
